<?php

/**
 * Created by PhpStorm.
 * User: Evgeni
 * Date: 09.11.2016
 * Time: 3:18
 */
include_once (ROOT.'/models/Model.php');
include_once (ROOT.'/views/View.php');

class Controller {

    protected $model;
    protected $view;

    function __construct() {
        $this->view = new View();
        $this->model = new Model();
    }

}