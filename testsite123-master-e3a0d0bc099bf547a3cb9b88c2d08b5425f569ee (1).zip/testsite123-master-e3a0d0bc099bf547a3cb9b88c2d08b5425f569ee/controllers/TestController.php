<?php

/**
 * Created by PhpStorm.
 * User: Evgeni
 * Date: 09.11.2016
 * Time: 2:52
 */
include_once (ROOT."/controllers/Controller.php");

class TestController extends Controller
{
    public function actionIndex()
    {
        $this->view->render($this->view->defaultLayot, array());
    }
}