<html>
	<head>
		<title>тестовое задание</title>
	</head>
	<body>
		<table>
			<tr>
 				 <td colspan=2><b>информация про клиента</b></td>
 			 </tr>
 			 <tr>
 				 <td >название клиента</td>
				<td >[name_customer]</td>
 			 </tr>
 			 <tr>
 				 <td >компания</td>
 				<td >[ company]</td>
 			 </tr>
 			 <tr>
 				 <td colspan=2><b>информация про договор</b></td>
 			 </tr>
			<tr>
 				 <td >номер договора</td>
 				<td >[ number]</td>
 			 </tr>
 			 <tr>
 				 <td >дата подписания</td>
 				<td >[ date_sign]</td>
 			 </tr>
 			 <tr>
 				 <td colspan=2><b>информация про сервисы</b></td>
 			 </tr>
 			 <tr>
[services_name]
				<!-- в services_name вывести название сервисов через <br> -->
			</tr>
		</table>
	</body>
</html>
