
/**
 * Created by PhpStorm.
 * User: Evgeni
 * Date: 09.11.2016
 * Time: 17:04
 */

<form action="" method="get">
    <input type="text" name="client">
    <input type="checkbox" name="work">
    <input type="checkbox" name="connecting">
    <input type="checkbox" name="disconnected">
    <input type="submit">
    <input type="reset">
</form>