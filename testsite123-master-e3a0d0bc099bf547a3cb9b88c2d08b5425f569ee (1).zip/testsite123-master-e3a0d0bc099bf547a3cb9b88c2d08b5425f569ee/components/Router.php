<?php

/**
 * Created by PhpStorm.
 * User: Evgeni
 * Date: 08.11.2016
 * Time: 20:11
 */
class Router
{
    private $routes;
    /**
     * Router constructor.
     */
    public function __construct()
    {
        $routePath = ROOT.'/config/routes.php';
        $this->routes = include($routePath);
    }

    private function getUri()
    {
        if ( ! empty($_SERVER['REQUEST_URI']))
            return trim($_SERVER['REQUEST_URI'], '/');
    }

    function run(){
        $uri = $this->getUri();

        foreach($this->routes as $pattern => $route) {

            if(preg_match("~$pattern~", $uri)){

                $internalRoute = preg_replace("~$pattern~", $route, $uri);
                $segments = explode('/', $internalRoute);
                $controller = ucfirst(array_shift($segments)).'Controller';
                $action = 'action'.ucfirst(array_shift($segments));
                $params = $segments;

                $controllerFile = ROOT.'/controllers/'.$controller.'.php';
                if(file_exists($controllerFile)){
                    include($controllerFile);
                }

                if(!is_callable(array($controller, $action))){
                    header("HTTP/1.0 404 Not Found");
                    return;
                }

                call_user_func_array(array($controller, $action), $params);
            }
        }

        header("HTTP/1.0 404 Not Found");
        return;
    }
}