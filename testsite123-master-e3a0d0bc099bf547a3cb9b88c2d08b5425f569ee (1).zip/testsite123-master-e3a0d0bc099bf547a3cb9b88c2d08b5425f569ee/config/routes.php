<?php
/**
 * Created by PhpStorm.
 * User: Evgeni
 * Date: 08.11.2016
 * Time: 20:11
 */

return array(
    '' => 'test/index'
);