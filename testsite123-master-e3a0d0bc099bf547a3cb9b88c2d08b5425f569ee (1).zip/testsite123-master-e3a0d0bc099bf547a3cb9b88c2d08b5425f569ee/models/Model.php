<?php

/**
 * Created by PhpStorm.
 * User: Evgeni
 * Date: 10.11.2016
 * Time: 22:47
 */
class Model
{
    public function __construct()
    {
        echo "LOL";
    }
}